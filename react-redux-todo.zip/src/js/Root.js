import React, { PropTypes } from 'react';
import { Provider } from 'react-redux';
import {BrowserRouter, Link, Route, Switch} from 'react-router-dom';
import App from './components/App';
import TodosPage from './components/todo/todosPage';
import NewTodoPage from './components/todo/newTodoPage';
import EditTodoPage from './components/todo/editTodoPage';


const Root = ({ store }) => (
  <Provider store={store}>
    <BrowserRouter>
      <Switch>
          <Route exact path="/" component={App} />
          <Route path="/new" component={NewTodoPage}/>
          <Route path="/todo/:id" component={EditTodoPage}/>
      </Switch>

    </BrowserRouter>
  </Provider>
);

Root.propTypes = {
  store: PropTypes.object.isRequired,
};

export default Root;

