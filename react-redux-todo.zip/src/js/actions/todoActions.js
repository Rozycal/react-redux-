
export const addTodo = (text, timestamp) => {
  return {
    type: 'ADD_TODO',
    id: timestamp,
    text
  }
}

export const removeTodo = (id) => {
  return {
    type: 'DELETE_TODO',
    id
  }
}

export const editTodo = (id,text) => {
  return {
    type: 'UPDATE_TODO',
    id,
    text
  }
}

export const toggleTodo = (id) => {
  return {
    type: 'TOGGLE_TODO',
    id
  }
}
