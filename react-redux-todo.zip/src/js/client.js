import React from 'react';
import { render } from 'react-dom'
import { createStore } from 'redux'
import rootReducer from './reducers'
import Root from './Root'

let store = createStore(rootReducer)
// Log the initial state
console.log(store.getState())

let unsubscribe = store.subscribe(() =>
  console.log(store.getState())
)

var ts = Date.now();
store.dispatch({ type: 'ADD_TODO', text: 'Clean House', id: ts })
store.dispatch({ type: 'ADD_TODO', text: 'Fix Window', id: ts + 20})
store.dispatch({ type: 'TOGGLE_TODO', id: ts })

// Stop listening to state updates
//unsubscribe()

render(
    <Root store={store} />,
    document.getElementById('app')
)

