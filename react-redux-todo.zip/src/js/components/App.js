import React, {PropTypes} from 'react'
import { render } from 'react-dom'
import HomePage from './todo/homePage';

class App extends React.Component {

  render() {
    return (
        <HomePage />
      );
  }
}

export default App;

