import React, {PropTypes} from 'react';

const TodoInput = ({name, onChange, placeholder, value}) => {
  let wrapperClass = "new-todo";

  return (
    <div className={wrapperClass}>
        <input
          type="text"
          name={name}
          className="form-control add-todo"
          placeholder={placeholder}
          value={value}
          onChange={onChange} />
    </div>
    );
};

TodoInput.propTypes= {
    name: PropTypes.string.isRequired,
    onChange: PropTypes.func,  //required
    placeholder: PropTypes.string,
    value: PropTypes.string,
}

export default TodoInput;