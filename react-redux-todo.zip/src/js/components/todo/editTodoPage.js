import React, {PropTypes} from 'react';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import * as todoActions from '../../actions/todoActions';
import TodoForm from './todoForm';

class EditTodoPage extends React.Component {
    constructor(props, context) {
        super(props, context);

        this.state = {
            todo: {text: ""}
    };

    this.handleChange = this.handleChange.bind(this);
    this.handleSave = this.handleSave.bind(this);
  }

  handleChange(event) {
    const todo = this.props.todo;
    if (todo){
    todo.text = event.target.value;
    this.setState({todo: todo});}
  }

  handleSave() {
    if ((this.state.todo.text) && this.state.todo.text.length>0)
    {
      this.props.actions.editTodo(this.state.todo.id, this.state.todo.text)
      this.redirectToTodosPage();
    this.setState({todo: {text: ""}});
    }
  }

  redirectToTodosPage() {
    this.context.router.history.push('/');
  }

  render() {
    return (<div>
      <TodoForm text={this.props.todo.text}
                onChange={this.handleChange}
                onSave={this.handleSave}
                value="Edit"/>
                </div>
    );
  };
}
EditTodoPage.propTypes = {
  actions: PropTypes.object.isRequired,
  todo: PropTypes.object.isRequired
};

EditTodoPage.contextTypes = {
  router: PropTypes.object
};

function getTodoById(todos, id) {
  if (todos === undefined)
    return null;
  const currentTodo = todos.find(todo => todo.id == id);
  if (!(currentTodo)) //shouldnt get here but just in case return back on invalid id
    redirectToTodosPage();
  return currentTodo;
}

function mapStateToProps(state, ownProps) {
   let todoToEdit = Object.assign({},getTodoById(state.todos, ownProps.match.params.id));

  return {
    todo: todoToEdit
  };
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(todoActions, dispatch)
  };
}

export default connect(mapStateToProps,mapDispatchToProps)(EditTodoPage);
