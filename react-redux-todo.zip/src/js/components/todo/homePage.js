
import React, {PropTypes} from 'react'
import { render } from 'react-dom'
import TodosPage from './todosPage';
import {Link} from 'react-router-dom';

class HomePage extends React.Component {

  handleAddTodoClick(){
    this.context.router.history.push('/new');
  }

  render() {
    return (
      <div>
        <h1>Todos</h1>
         <button className="btn btn-success"
                  onClick={this.handleAddTodoClick.bind(this)}>Add Todo</button>
         <hr/>
         <TodosPage />
      </div>
      );
  }
}

HomePage.contextTypes = {
  router: PropTypes.object
};


export default HomePage;

