import React, {PropTypes} from 'react';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import * as todoActions from '../../actions/todoActions';
import TodoForm from './todoForm';

class NewTodoPage extends React.Component {
    constructor(props, context) {
        super(props, context);

        this.state = {
            todo: {text: ""}
    };

    this.handleChange = this.handleChange.bind(this);
    this.handleSave = this.handleSave.bind(this);
  }

  handleChange(event) {
    const todo = this.state.todo;
    todo.text = event.target.value;
    this.setState({todo: todo});
  }

  handleSave() {
    if ((this.state.todo.text) && this.state.todo.text.length>0){
      this.props.actions.addTodo(this.state.todo.text, Date.now())
      this.redirectToTodosPage();
      this.setState({todo: {text: ""}});
  }
}

  redirectToTodosPage() {
    this.context.router.history.push('/');
  }

  render() {
    return (<div>
      <TodoForm text={this.state.todo.text}
                onChange={this.handleChange}
                onSave={this.handleSave}
                value="Add Todo"/>
                </div>

    );
  };
}
NewTodoPage.propTypes = {
  actions: PropTypes.object.isRequired,
  todos: PropTypes.array.isRequired
};

NewTodoPage.contextTypes = {
  router: PropTypes.object
};

function mapStateToProps(state, ownProps) {
  return {
    todos: state.todos
  };
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(todoActions, dispatch)
  };
}

export default connect(mapStateToProps,mapDispatchToProps)(NewTodoPage);
