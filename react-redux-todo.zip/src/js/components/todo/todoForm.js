import React, {PropTypes} from 'react'
import TodoInput from '../common/todoInput'
import { Link } from 'react-router-dom';


const TodoForm = ({text, onChange, onSave, value}) => {

  return (
    <div>
        <TodoInput
          name="text"
          placeholder="Add Todo"
          value={text}
          onChange={onChange} />

        <input
          type="submit"
          value={value}
          className="btn btn-success"
          onClick={onSave}/>

        <Link className="btn btn-success form-buttons" role="button" to="/">Back</Link>

     </div>
    );
};

TodoForm.propTypes = {
  text: PropTypes.string.isRequired,
  onChange: PropTypes.func.isRequired,
  onSave: PropTypes.func.isRequired
}

export default TodoForm;