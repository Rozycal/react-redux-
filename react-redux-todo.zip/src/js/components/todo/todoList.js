import React, {PropTypes} from 'react';
import TodoListRow from './todoListRow';


const TodoList = ({todos, onTodoClick, onClickDelete,counterUnfinished}) => (
<div>
    <ul id="sortable" class="list-unstyled ">
     {todos.map( todo =>
        <TodoListRow
            key={todo.id}
            {...todo}
            onClick={() => onTodoClick(todo.id)}
            onClickDelete={() => onClickDelete(todo.id)}/>
         )
        }
    </ul>
  <div className="todo-footer">
    <strong><span className="count todo">Items left to do: {counterUnfinished}</span></strong>
  </div>
</div>

);

TodoList.propTypes = {
  todos: PropTypes.arrayOf(PropTypes.shape({
    id: PropTypes.number.isRequired,
    text: PropTypes.string.isRequired,
    finished: PropTypes.bool.isRequired
  }).isRequired).isRequired,
  onTodoClick: PropTypes.func,
  onClickDelete: PropTypes.func,
  counterUnfinished: PropTypes.number.isRequired
}

export default TodoList;