import React, {PropTypes} from 'react';
import {Link} from 'react-router-dom';

const TodoListRow = ({ text, finished, id, onClick, onClickDelete }) => {

  var wrapperClassTodo = "unchecked";
  if (finished) {
    wrapperClassTodo ="checked";
  }

  function handleClick(e) {
    e.preventDefault();
    e.stopPropagation();
    onClickDelete();
  }

  function handleClickEdit(e) {
    e.preventDefault(); // Let's stop this event.
    e.stopPropagation(); // Really this time.
  }

  return (
    <li className="ui-state-default"
        onClick={onClick} >
        <div className={wrapperClassTodo}>
            <label >{text}</label>
            <span className="todo-buttons pull-right">
                <button className="btn" onClick={handleClickEdit}><Link to={'/todo/' + id}>Edit</Link></button>
                <button className="btn" onClick={handleClick}>Delete</button>
            </span>
        </div>
    </li>
    );
};

TodoListRow.propTypes = {
    text: PropTypes.string.isRequired,
    finished: PropTypes.bool.isRequired,
    id: PropTypes.number.isRequired,
    onClick: PropTypes.func,
    onClickEdit: PropTypes.func
};

export default TodoListRow;

