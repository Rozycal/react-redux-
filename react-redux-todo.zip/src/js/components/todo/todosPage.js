import { connect } from 'react-redux'
import * as todoActions from '../../actions/todoActions';
import TodoList from './todoList';

const mapStateToProps = (state, ownProps) => {

  const counterUnfinished = state.todos.filter( todo => {
        return todo.finished === false }).length;

  return {todos: state.todos,
          counterUnfinished: counterUnfinished}
}

const mapDispatchToProps = (dispatch) => {
  return {

    onTodoClick: (id) => {
      dispatch(todoActions.toggleTodo(id))},

    onClickDelete: (id) => {
      dispatch(todoActions.removeTodo(id))}
  }
}

const TodosPage = connect(
  mapStateToProps,
  mapDispatchToProps
)(TodoList)

export default TodosPage;