const todo = (state = {}, action) => {
  switch (action.type) {
    case 'ADD_TODO':
        return {
            id: action.id,
            text: action.text,
            finished: false
        };

    case 'UPDATE_TODO':
        if( state.id !== action.id) {
            return state
        }
        return Object.assign({}, state, {
                text: action.text })

    case 'TOGGLE_TODO':
        if( state.id !== action.id) {
            return state
        }
        return Object.assign({}, state, {
                finished: !state.finished })

    default:
        return state;
    }
}

const todosReducer = (state = [], action) => {
  switch (action.type) {
    case 'ADD_TODO':
        return [...state,
                    todo(undefined, action)]

    case 'UPDATE_TODO':
      return state.map(todo1 =>
        todo(todo1, action)
      )

    case 'TOGGLE_TODO':
      return state.map(todo1 =>
        todo(todo1, action)
      )

    case 'DELETE_TODO': {
      var newState = state.filter( todo1 => {
        return todo1.id !== action.id })
      return newState
    }

    default:
        return state
    }
}

export default todosReducer;
