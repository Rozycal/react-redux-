<?php

namespace App\Http\Controllers;

use App\Todo;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Http\Controllers\Controller;


class todoApiController extends Controller
{
    public function getIndex()
    {
        $todos = Todo::all();
        return $this->resolveResponseMessage($todos, Response()->json([
            'error' => false,
            'todos' => $todos,
            'status_code' => 200]));
    }

   public function postTodo(Request $request)
    {
        $this->validate($request,[
            "name"=>'required|min:3|max:60',
            "finished"=>''
            ]);
        $todo = new Todo([
            'name' => $request->input('name'),
            'finished' => 0
            ]);

        $todo->save();
        return $this->resolveResponseMessage($todo, Response()->json([
            'error' => false,
            'todo' => $todo,
            'status_code' => 200]));
    }

    public function deleteTodo($id)
    {
        $todo = Todo::find($id);
        $todo->delete();
        return $this->resolveResponseMessage($todo, Response()->json([
            'error' => false,
            'id' => $id,
            'status_code' => 200]));
    }

    public function putTodo(Request $request)
    {
        $this->validate($request,[
            "name"=>'required|min:3|max:60'
            ]);
        $todo = Todo::find($request->input('id'));
        $todo->name = $request->input('name');
        $todo->finished = $request->input('finished');

        $todo->save();
        return $this->resolveResponseMessage($todo, Response()->json([
            'error' => false,
            'todo' => $todo,
            'status_code' => 200]));
    }


    private function resolveResponseMessage($val, $msg)
    {
        if ($val == null)
            return Response()->json([
                'error' => false,
                'status_code' => 204]);
        else
            return $msg;
    }
}
