<?php

namespace App\Http\Controllers;

use App\Todo;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class todoController extends Controller
{
    public function getIndex()
    {
        $todos = Todo::orderBy('created_at','desc')->paginate(3);
        return view("todos.index", ["todos" => $todos] );
    }

    public function getTodo($id)
    {
        $todo = Todo::find($id);
        return view("todos.todo",["todo"=> $todo, "todoId"=>$id ]);
    }

   public function postTodoCreate(Request $request)
    {
        $this->validate($request,[
            "name"=>'required|min:5|max:60',
            "finished"=>''
            ]);
        $todo = new Todo([
            'name' => $request->input('name'),
            'finished' => 0
            ]);

        $todo->save();
        return redirect()->route("todos.index")->with("info","Item created: " .$request->input("name"));
    }

    public function getTodoDelete($id)
    {
        $todo = Todo::find($id);
        $todo->delete();
        return redirect()->route("todos.index")->with("info","Item deleted. ");
    }

    public function postTodoEdit(Request $request)
    {
        $this->validate($request,[
            "name"=>'required|min:5|max:60',
            "finished"=>''
            ]);
        $todo = Todo::find($request->input('id'));
        $todo->name = $request->input('name');

        $todo->save();
        return redirect()->route("todos.index")->with("info","Item edited: " .$request->input("name"));
    }

    public function getTodoFinished($id)
    {
        $todo = Todo::find($id);
        $todo->finished = 1;

        $todo->save();
        return redirect()->route("todos.index")->with("info","Item marked as Done. " );
    }




}
