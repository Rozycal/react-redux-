@extends('layouts.master')

@section('content')

<div class="container">
    <div class="row">
        <div class="col-md-2">
        </div>
        <div class="col-md-8">
            <div id="app" class="todolist not-done">
                <h1>To Do List</h1><hr>
                    <form action="{{route('todos.edit')}}" method="post">
                    @include("partials.errors")
                        <div class="new-todo">
                            <input type="text" class="form-control add-todo" name="name"  value="{{ $todo->name }}"/>

                            <span class="pull-left" >
                                <input type="hidden" name="id" value="{{$todoId}}">
                                <button type="submit" class="btn btn-primary" id="todoButtons">Edit</button>
                                <a href="{{ route('todos.index') }}" class="btn btn-primary" id="todoButtons">Back</a>
                            </span>
                        </div>
                        {{csrf_field()}}
                    </form>
                    @if(Session::has("info"))
                    <div class="row" id="alert-info">
                        <div class="col-md-12">
                            <p class="alert alert-info">{{Session::get('info')}}</p>
                        </div>
                    </div>
                    @endif
            </div>
        </div>
    </div>
</div>

@endsection