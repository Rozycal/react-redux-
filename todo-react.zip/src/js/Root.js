import React, { PropTypes } from 'react';
import { Provider } from 'react-redux';
import {BrowserRouter, Route, Switch, Redirect} from 'react-router-dom';
import App from './components/App';
import NewTodoPage from './components/todo/newTodoPage';
import EditTodoPage from './components/todo/editTodoPage';

//const Root = ({ store }) => (
class Root extends React.Component {
  constructor(props, context) {
      super(props, context);
  };

  render() {
    return(
      <Provider store={this.props.store}>
        <BrowserRouter>
          <Switch>
              <Route exact path="/" component={App} />
              <Route path="/new" component={NewTodoPage}/>
              <Route path="/todo/:id" component={EditTodoPage}/>
              <Redirect to="/" component={App}/>
          </Switch>
        </BrowserRouter>
      </Provider>
    );
  };
};

Root.propTypes = {
  store: PropTypes.object.isRequired,
};

export default Root;

