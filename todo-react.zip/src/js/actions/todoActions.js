
export const addTodo = (text) => {
  return {
    type: 'ADD_TODO',
    payload: {
      request:{
        method: 'POST',
        url:'/todos',
        data: { name: text }
      }
    }
  }
}

export const removeTodo = (id) => {
  return {
    type: 'DELETE_TODO',
    payload: {
      request:{
        method: 'DELETE',
        url:'/todos/'+id
      }
    }
  }
}

export const editTodo = (todo) => {
  return {
    type: 'UPDATE_TODO',
    payload: {
      request:{
        method: 'PUT',
        url:'/todos',
        data: { id: todo.id, name: todo.text, finished: todo.finished }
      }
    }
  }
}

export const toggleTodo = (todo) => {
  return {
    type: 'TOGGLE_TODO',
    payload: {
      request:{
        method: 'PUT',
        url:'/todos',
        data: { id: todo.id, name: todo.text, finished: !todo.finished}
      }
    }
  }
}

export const fetchTodos = () => {
  return {
    type: 'FETCH_TODOS',
    payload: {
      request:{
        url:'/todos'
      }
    }
  }
}


