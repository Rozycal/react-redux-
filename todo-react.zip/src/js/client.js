import React from 'react';
import axios from 'axios';
import axiosMiddleware from 'redux-axios-middleware';
import { render } from 'react-dom'
import { createStore, applyMiddleware } from 'redux'
import rootReducer from './reducers'
import Root from './Root'
import * as todoActions from './actions/todoActions';

const client = axios.create({ //all axios can be used, shown in axios documentation
  baseURL:'http://localhost/todo/public/api',
  responseType: 'json'
});

let store = createStore(
    rootReducer,
    applyMiddleware(axiosMiddleware(client)));

store.dispatch(todoActions.fetchTodos());

// Every time the state changes, log it
let unsubscribe = store.subscribe(() =>
  console.log(store.getState())
)

// Stop listening to state updates
//unsubscribe()

render(
    <Root store={store} />,
    document.getElementById('app')
)

