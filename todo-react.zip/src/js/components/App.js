import React, {PropTypes} from 'react'
import { render } from 'react-dom'
import {Link} from 'react-router-dom';
import HomePage from './todo/homePage';

class App extends React.Component {
  constructor(props, context) {
      super(props, context);
  };

  render() {
    return (
      <div>
        <h1>Todos</h1>
          <Link to="new" className="btn btn-success">Add Todo</Link>
          <hr/>
          <HomePage />
      </div>
    );
  };
};

export default App;

