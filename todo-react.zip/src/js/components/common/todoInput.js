import React, {PropTypes} from 'react';

//const TodoInput = ({name, onChange, placeholder, value}) => {
class TodoInput extends React.Component {
  constructor(props, context) {
      super(props, context);
  };

  render() {
    return (
      <div className="new-todo">
          <input
            type="text"
            name={this.props.name}
            className="form-control add-todo"
            placeholder={this.props.placeholder}
            value={this.props.value}
            onChange={this.props.onChange} />
      </div>
      );
  };
};

TodoInput.propTypes= {
    name: PropTypes.string.isRequired,
    onChange: PropTypes.func.isRequired,
    value: PropTypes.string.isRequired,
    placeholder: PropTypes.string
}

export default TodoInput;