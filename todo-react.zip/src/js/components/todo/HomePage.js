import React, {PropTypes} from 'react'
import { render } from 'react-dom'
import { connect } from 'react-redux'
import * as todoActions from '../../actions/todoActions';
import TodoList from './todoList';

const mapStateToProps = (state, ownProps) => {

  const counterUnfinished = state.todos.filter( todo => {
        return todo.finished === false }).length;

  return {todos: state.todos,
          counterUnfinished: counterUnfinished}
}

const mapDispatchToProps = (dispatch) => {
  return {

    onClickTodo: (id) => {
      dispatch(todoActions.toggleTodo(id))},

    onClickDelete: (id) => {
      dispatch(todoActions.removeTodo(id))}
  }
}

const HomePage =  connect(mapStateToProps,mapDispatchToProps)(TodoList);
export default HomePage;


