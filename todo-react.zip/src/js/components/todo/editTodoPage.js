import React, {PropTypes} from 'react';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import * as todoActions from '../../actions/todoActions';
import TodoForm from './todoForm';
import TodoError from './todoError';

class EditTodoPage extends React.Component {
    constructor(props, context) {
        super(props, context);

        this.state = {
            todo: {text: ""},
            error: ""
        };

    this.handleChange = this.handleChange.bind(this);
    this.handleSave = this.handleSave.bind(this);
  }

  handleChange(event) {
    const todo = this.props.todo;
    if (todo){
    todo.text = event.target.value;
    this.setState({todo: todo});}
  }

  handleSave() {
    var currTodo = this.state.todo.text;
    if ((this.props.todo.text) && !(currTodo))
      { this.setState({error: "The record hasn't been changed"});}
    else if ((this.state.todo.text.length<=2) || !(currTodo))
      { this.setState({error: "Records must contain at least 3 characters"});}
    else {
      this.props.actions.editTodo(this.state.todo);
      this.redirectToHomePage();
    }
  }

  redirectToHomePage() {
    this.context.router.history.push('/');
  }

  render() {
    return (<div>
      <TodoError error={this.state.error} />
      <TodoForm text={this.props.todo.text}
                onChange={this.handleChange}
                onSave={this.handleSave}
                value="Edit"/>
                </div>
    );
  };
}
EditTodoPage.propTypes = {
  actions: PropTypes.object.isRequired,
  todo: PropTypes.object.isRequired
};

EditTodoPage.contextTypes = {
  router: PropTypes.object
};

function getTodoById(todos, id) {
  if (todos === undefined)
    return null;
  const currentTodo = todos.find(todo => todo.id == id);
  if (!(currentTodo)) //shouldnt get here but just in case return back on invalid id
    redirectToHomePage();
  return currentTodo;
}

function mapStateToProps(state, ownProps) {
   let todoToEdit = Object.assign({},getTodoById(state.todos, ownProps.match.params.id));

  return {
    todo: todoToEdit
  };
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(todoActions, dispatch)
  };
}

export default connect(mapStateToProps,mapDispatchToProps)(EditTodoPage);
