import React, {PropTypes} from 'react';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import * as todoActions from '../../actions/todoActions';
import TodoForm from './todoForm';
import TodoError from './todoError';

class NewTodoPage extends React.Component {
    constructor(props, context) {
        super(props, context);

        this.state = {
            todo: {text: ""},
            error: ""
    };

    this.handleChange = this.handleChange.bind(this);
    this.handleSave = this.handleSave.bind(this);
  }

  handleChange(event) {
    const todo = this.state.todo;
    todo.text = event.target.value;
    this.setState({todo: todo});
  }

  handleSave() {
   if ((this.state.todo.text) && this.state.todo.text.length>2){
      this.props.actions.addTodo(this.state.todo.text);
      this.redirectToHomePage();
   }
   else this.setState({error: "Records must contain at least 3 characters"});
  }

  redirectToHomePage() {
    this.context.router.history.push('/');
  }

  render() {
    return (<div>
      <TodoError error={this.state.error} />
      <TodoForm text={this.state.todo.text}
                onChange={this.handleChange}
                onSave={this.handleSave}
                value="Add Todo"/>
                </div>

    );
  };
}

NewTodoPage.propTypes = {
  actions: PropTypes.object.isRequired,
  todos: PropTypes.array
};

NewTodoPage.contextTypes = {
  router: PropTypes.object
};

function mapStateToProps(state, ownProps) {
  return {
    todos: state.todos
  };
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(todoActions, dispatch)
  };
}

export default connect(mapStateToProps,mapDispatchToProps)(NewTodoPage);

