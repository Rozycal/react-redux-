import React, {PropTypes} from 'react';

class TodoError extends React.Component {
    constructor(props, context) {
        super(props, context);

  }

 render() {
  if(this.props.error){
  return (
    <div class="alert alert-danger alert-dismissable">
        <strong>Error: </strong> {this.props.error}.
    </div>
    );}
  else return (<div/>);
 };
};


TodoError.propTypes = {
    error: PropTypes.string.isRequired,

};

export default TodoError;
