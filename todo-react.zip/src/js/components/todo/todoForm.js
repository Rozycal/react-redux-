import React, {PropTypes} from 'react'
import TodoInput from '../common/todoInput'
import { Link } from 'react-router-dom';


//const TodoForm = ({text, onChange, onSave, value}) => {
class TodoForm extends React.Component {
  constructor(props, context) {
      super(props, context);
  };

  render() {

    return (
      <div>
          <TodoInput
            name="text"
            placeholder="Add Todo"
            value={this.props.text}
            onChange={this.props.onChange} />

          <input
            type="submit"
            value={this.props.value}
            className="btn btn-success"
            onClick={this.props.onSave}/>

          <Link className="btn btn-success form-buttons" to="/">Back</Link>

       </div>
      );
  };
};

TodoForm.propTypes = {
  text: PropTypes.string.isRequired,
  value: PropTypes.string.isRequired,
  onChange: PropTypes.func.isRequired,
  onSave: PropTypes.func.isRequired
}

export default TodoForm;