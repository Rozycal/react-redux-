import React, {PropTypes} from 'react';
import TodoListRow from './todoListRow';


//const TodoList = ({todos, onClickTodo, onClickDelete,counterUnfinished}) => (
class TodoList extends React.Component {
  constructor(props, context) {
      super(props, context);
  };

  render() {
    return (<div>
      <ul id="sortable" class="list-unstyled ">
       {this.props.todos.map( todo =>
          <TodoListRow
              key={todo.id}
              {...todo}
              onClickTodo={() => this.props.onClickTodo(todo)}
              onClickDelete={() => this.props.onClickDelete(todo.id)}/>
           )
          }
      </ul>
    <div className="todo-footer">
      <strong><span className="count todo">Items left to do: {this.props.counterUnfinished}</span></strong>
    </div>
  </div>
  );
 };
};

TodoList.propTypes = {
  todos: PropTypes.arrayOf(PropTypes.shape({
    id: PropTypes.number.isRequired,
    text: PropTypes.string.isRequired,
    finished: PropTypes.bool.isRequired
  }).isRequired).isRequired,
  onClickTodo: PropTypes.func.isRequired,
  onClickDelete: PropTypes.func,
  counterUnfinished: PropTypes.number.isRequired
}

export default TodoList;