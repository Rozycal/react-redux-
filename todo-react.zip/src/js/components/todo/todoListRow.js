import React, {PropTypes} from 'react';
import {Link} from 'react-router-dom';

//const TodoListRow = ({ text, finished, id, onClickTodo, onClickDelete }) => {
class TodoListRow extends React.Component {
    constructor(props, context) {
        super(props, context);

        this.state = {
            todo: {text: ""}
    };

    this.handleClick = this.handleClick.bind(this);
    this.handleClickEdit = this.handleClickEdit.bind(this);

  }
  handleClick(e) {
    e.preventDefault(); // Let's stop this event.
    e.stopPropagation(); // Really this time.
    this.props.onClickDelete();
  }

  handleClickEdit(e) {
    e.preventDefault(); // Let's stop this event.
    e.stopPropagation(); // Really this time.
    this.context.router.history.push('/todo/' + this.props.id);
  }

 render() {
  var wrapperClassTodo = "unchecked";
  if (this.props.finished) {
    wrapperClassTodo ="checked";
  };

  return (
    <li className="ui-state-default"
        onClick={this.props.onClickTodo} >
        <div className={wrapperClassTodo}>
            <label >{this.props.text}</label>
            <span className="todo-buttons pull-right">
                <button className="btn" onClick={this.handleClickEdit}>Edit</button>
                <button className="btn" onClick={this.handleClick}>Delete</button>
            </span>
        </div>
    </li>
    );
  };
};

TodoListRow.propTypes = {
    text: PropTypes.string.isRequired,
    finished: PropTypes.bool.isRequired,
    id: PropTypes.number.isRequired,
    onClickTodo: PropTypes.func.isRequired,
    onClickDelete: PropTypes.func
};
TodoListRow.contextTypes = {
  router: PropTypes.object
};


export default TodoListRow;

