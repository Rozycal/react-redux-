
const todosReducer = (state = [], action) => {
  switch (action.type) {
    case 'ADD_TODO': { return state; }
    case 'ADD_TODO_SUCCESS':
    {
        var createdTodo = {
            id: action.payload.data.todo.id,
            text: action.payload.data.todo.name,
            finished: false}
        return [...state, createdTodo];
    }
    case 'ADD_TODO_FAIL':{
        confirm(action.error.message+" "+action.error.response.statusText);
    }

    case 'UPDATE_TODO': { return state; }
    case 'UPDATE_TODO_SUCCESS': {
    if (action.payload.data.todo.id) {
      const newState = state.map( todo1 => {
        if (todo1.id != action.payload.data.todo.id){
            return todo1;
        }
        else return Object.assign({}, todo1 , {text: action.payload.data.todo.name});
    });
      return newState;
    }
    else return state;
    }
    case 'UPDATE_TODO_FAIL':{
        confirm(action.error.message+" "+action.error.response.statusText);
    }

    case 'TOGGLE_TODO': { return state; }
    case 'TOGGLE_TODO_SUCCESS': {
    if (action.payload.data.todo.id) {
      const newState = state.map( todo1 => {
        if (todo1.id != action.payload.data.todo.id){
            return todo1;
        }
        else return Object.assign({}, todo1 , {finished: !todo1.finished});
    });
      return newState;
    }
      else return state;
    }
    case 'TOGGLE_TODO_FAIL':{
      confirm(action.error.message+" "+action.error.response.statusText);
    }


    case 'DELETE_TODOS': { return state; }
    case 'DELETE_TODO_SUCCESS': {
      const newState = state.filter( todo1 => {
        return todo1.id != action.payload.data.id })
      return newState
    }
    case 'DELETE_TODO_FAIL': {
      confirm(action.error.message+" "+action.error.response.statusText);
    }

    case 'FETCH_TODOS': { return state; }
    case 'FETCH_TODOS_SUCCESS': {
      if (action.payload.data.todos){
        var todos = action.payload.data.todos.map(todoResponse => {
        return {
          id: todoResponse.id,
          text: todoResponse.name,
          finished: todoResponse.finished == 1
          }
        });
        return todos;
      }
      else return state;
    }
    case 'FETCH_TODOS_FAIL': {
      confirm(action.error.message+" "+action.error.response.statusText);
    }

    default:
        return state
    }
}

export default todosReducer;
